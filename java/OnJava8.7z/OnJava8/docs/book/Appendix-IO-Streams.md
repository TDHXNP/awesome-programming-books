[TOC]

<!-- Appendix: I/O Streams -->
# 附录:流式IO


<!-- Types of InputStream -->
## 输入流类型


<!-- Types of OutputStream -->
## 输出流类型


<!-- Adding Attributes and Useful Interfaces -->
## 添加属性和有用的接口


<!-- Readers & Writers -->
## Reader和Writer


<!-- Off By Itself: RandomAccessFile -->
## RandomAccessFile类


<!-- Typical Uses of I/O Streams -->
## IO流典型用途


<!-- Summary -->
## 本章小结


<!-- 分页 -->

<div style="page-break-after: always;"></div>