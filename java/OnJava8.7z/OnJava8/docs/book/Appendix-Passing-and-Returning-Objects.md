[TOC]

<!-- Appendix: Passing and Returning Objects -->
# 附录:对象传递和返回


<!-- Passing References -->
## 传递引用


<!-- Making Local Copies -->
## 本地拷贝


<!-- Controlling Cloneability -->
## 控制克隆


<!-- Immutable Classes -->
## 不可变类


<!-- Summary -->
## 本章小结



<!-- 分页 -->

<div style="page-break-after: always;"></div>