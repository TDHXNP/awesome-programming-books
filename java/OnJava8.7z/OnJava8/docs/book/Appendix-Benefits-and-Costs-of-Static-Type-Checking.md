[TOC]

<!-- Appendix: Benefits and Costs of Static Type Checking -->
# 附录:静态语言类型检查


<!-- Foreword -->
## 前言


<!-- Static Type Checking vs. Testing -->
## 静态类型检查和测试


<!-- How to Argue about Typing -->
## 如何提升打字


<!-- The Cost of Productivity -->
## 生产力的成本


<!-- Static vs. Dynamic -->
## 静态和动态


<!-- 分页 -->

<div style="page-break-after: always;"></div>