[TOC]

<!-- Appendix: Standard I/O -->
# 附录:标准IO

<!-- Process Control -->
## 执行控制

<!-- 分页 -->

<div style="page-break-after: always;"></div>